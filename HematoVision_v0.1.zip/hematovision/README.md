# HematoVision v0.1

Protótipo educacional de processamento de imagens microscópicas. **Não realiza diagnóstico nem contagem de células.**

## Windows (Python 3.13)
1. Extraia o ZIP.
2. Abra a pasta no VS Code.
3. Execute `iniciar_windows.bat` com duplo clique. Na primeira execução, aguarde a instalação das dependências.
4. O navegador abrirá o Streamlit (geralmente em http://localhost:8501).

## Terminal do VS Code (alternativa)
```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Se já existir `.venv` mas faltar alguma biblioteca, execute novamente o comando `pip install -r requirements.txt` acima.

## Estrutura
- `app.py`: interface Streamlit
- `src/processing.py`: funções OpenCV
- `.streamlit/config.toml`: tema
- `requirements.txt`: dependências

## Limitações
Contornos podem corresponder a artefatos, células sobrepostas ou outras estruturas. Não há modelo de IA treinado nesta versão. Use apenas imagens públicas ou autorizadas, sem dados identificáveis de pacientes.
