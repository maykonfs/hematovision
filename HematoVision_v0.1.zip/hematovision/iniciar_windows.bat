@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.13 -m venv .venv
  if errorlevel 1 (
    echo Python 3.13 nao encontrado. Instale Python 3.13 e tente novamente.
    pause
    exit /b 1
  )
  .venv\Scripts\python.exe -m pip install --upgrade pip
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Falha na instalacao das dependencias.
    pause
    exit /b 1
  )
)
.venv\Scripts\python.exe -m streamlit run app.py
pause
