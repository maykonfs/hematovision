import io
import cv2
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image, UnidentifiedImageError
from src.processing import analyze

st.set_page_config(page_title="HematoVision", page_icon="🔬", layout="wide")
st.markdown("""<style>
.stApp {background: #0b1020; color: #e8efff;}
[data-testid="stSidebar"] {background: #111a30;}
h1,h2,h3 {color:#e9f1ff!important;}
[data-testid="stMetric"] {background:#17223a; padding:16px; border-radius:12px;}
.stButton button, .stDownloadButton button {border-radius:10px;}
</style>""", unsafe_allow_html=True)

st.title("🔬 HematoVision")
st.caption("Laboratório digital • Protótipo educacional v0.1")
st.warning("Análise experimental de contornos. NÃO identifica tipos celulares, não estima hemograma e não serve para diagnóstico.")
with st.sidebar:
    st.header("Configurações")
    min_area = st.slider("Área mínima de contorno (pixels²)", 20, 2000, 120, 20)
    st.info("Ajuste o controle para filtrar contornos pequenos. O número exibido não representa uma contagem de células.")

file = st.file_uploader("Envie uma imagem microscópica (PNG, JPG ou JPEG)", type=["png", "jpg", "jpeg"])
if file is None:
    st.info("Envie uma imagem para iniciar a análise. Nenhum arquivo é transmitido a uma API externa pelo código deste protótipo.")
    st.stop()
try:
    raw = file.getvalue()
    if len(raw) > 15 * 1024 * 1024:
        st.error("Arquivo acima do limite de 15 MB.")
        st.stop()
    pil = Image.open(io.BytesIO(raw))
    if pil.width * pil.height > 20_000_000:
        st.error("Imagem grande demais (máximo 20 megapixels).")
        st.stop()
    rgb = np.array(pil.convert("RGB"))
except (UnidentifiedImageError, OSError, ValueError) as exc:
    st.error(f"Não foi possível abrir a imagem: {exc}")
    st.stop()

result = analyze(rgb, min_area)
a,b,c = st.columns(3)
a.metric("Largura", f"{result['width']} px")
b.metric("Altura", f"{result['height']} px")
c.metric("Contornos candidatos", result["candidates"])

left,right = st.columns(2)
with left:
    st.subheader("Imagem original")
    st.image(rgb, use_container_width=True)
with right:
    st.subheader("Contornos destacados")
    st.image(result["overlay"], use_container_width=True)

with st.expander("Ver etapas do processamento"):
    p,q,r = st.columns(3)
    p.image(result["gray"], caption="Escala de cinza", use_container_width=True)
    q.image(result["enhanced"], caption="Contraste CLAHE", use_container_width=True)
    r.image(result["edges"], caption="Bordas Canny", use_container_width=True)

success, encoded = cv2.imencode(".png", cv2.cvtColor(result["overlay"], cv2.COLOR_RGB2BGR))
if success:
    st.download_button("Baixar imagem processada", encoded.tobytes(), "hematovision_contornos.png", "image/png")
summary = pd.DataFrame([{"largura_px":result["width"], "altura_px":result["height"], "contornos_candidatos":result["candidates"], "area_minima_px2":min_area}])
st.download_button("Baixar métricas CSV", summary.to_csv(index=False).encode("utf-8"), "hematovision_metricas.csv", "text/csv")
