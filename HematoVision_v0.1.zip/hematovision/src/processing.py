import cv2
import numpy as np


def analyze(image_rgb: np.ndarray, min_area: int = 120):
    """Detecta contornos candidatos; NÃO identifica nem conta células clinicamente."""
    gray = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2GRAY)
    enhanced = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    blurred = cv2.GaussianBlur(enhanced, (5, 5), 0)
    edges = cv2.Canny(blurred, 45, 110)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = [c for c in contours if cv2.contourArea(c) >= min_area]
    overlay = image_rgb.copy()
    cv2.drawContours(overlay, candidates, -1, (32, 220, 190), 2)
    return {"gray": gray, "enhanced": enhanced, "edges": edges, "overlay": overlay,
            "candidates": len(candidates), "width": image_rgb.shape[1], "height": image_rgb.shape[0]}
